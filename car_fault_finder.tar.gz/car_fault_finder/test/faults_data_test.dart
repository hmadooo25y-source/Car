import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

import 'package:car_fault_finder/models.dart';
import 'package:car_fault_finder/repository.dart';
import 'package:car_fault_finder/strings.dart';

/// Reads the JSON files directly from disk so the test runs without a device.
List<Fault> _loadAllFaults() {
  final faults = <Fault>[];
  for (final path in kDataFiles) {
    final data = json.decode(File(path).readAsStringSync()) as Map<String, dynamic>;
    faults.addAll((data['faults'] as List)
        .map((e) => Fault.fromJson(e as Map<String, dynamic>)));
  }
  return faults;
}

const _symptoms = [
  'blue_smoke',
  'white_smoke',
  'knocking',
  'overheating',
  'squealing',
  'check_engine',
  'hard_start',
  'rough_idle',
  'oil_leak',
  'brake_noise',
];

void main() {
  final faults = _loadAllFaults();

  test('fault ids are unique', () {
    final ids = faults.map((f) => f.id).toList();
    expect(ids.toSet().length, ids.length);
  });

  test('every fault has Arabic and English text with at least 3 steps', () {
    for (final f in faults) {
      expect(f.texts.containsKey('ar'), isTrue, reason: f.id);
      expect(f.texts.containsKey('en'), isTrue, reason: f.id);
      for (final lang in ['ar', 'en']) {
        expect(f.texts[lang]!.steps.length, greaterThanOrEqualTo(3),
            reason: '${f.id}/$lang');
      }
    }
  });

  test('ranges and enums are valid', () {
    for (final f in faults) {
      expect(f.yearFrom <= f.yearTo, isTrue, reason: f.id);
      expect(f.costMinIls <= f.costMaxIls, isTrue, reason: f.id);
      expect(['any', 'petrol', 'diesel'], contains(f.engine), reason: f.id);
      expect(['low', 'medium', 'high', 'critical'], contains(f.severity),
          reason: f.id);
    }
  });

  test('every make referenced by a fault is in the dropdown list', () {
    for (final f in faults) {
      for (final m in f.makes) {
        expect(kMakes, contains(m), reason: f.id);
      }
    }
  });

  test('every symptom has at least one fault and a translated label', () {
    for (final s in _symptoms) {
      expect(faults.any((f) => f.symptoms.contains(s)), isTrue, reason: s);
      expect(tr('sym_$s'), isNot(equals('sym_$s')), reason: s);
    }
  });
}
