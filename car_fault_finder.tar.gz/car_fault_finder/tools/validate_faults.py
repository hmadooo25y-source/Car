import json, sys
SYMPTOMS = {"blue_smoke","white_smoke","knocking","overheating","squealing","check_engine","hard_start","rough_idle","oil_leak","brake_noise"}
MAKES = {"Toyota","Hyundai","Kia","Nissan","Chevrolet","Mercedes-Benz","BMW","Peugeot","Renault","Volkswagen","Skoda","Mazda","Honda","Ford"}
ENGINES = {"any","petrol","diesel"}
SEV = {"low","medium","high","critical"}
files = ["assets/data/faults.json", "assets/data/faults_more.json"]
ids, errors, total = set(), [], 0
used_symptoms = set()
for f in files:
    data = json.load(open(f, encoding="utf-8"))
    for x in data["faults"]:
        total += 1
        i = x["id"]
        if i in ids: errors.append(f"dup id {i}")
        ids.add(i)
        for s in x["symptoms"]:
            used_symptoms.add(s)
            if s not in SYMPTOMS: errors.append(f"{i}: unknown symptom {s}")
        for m in x["makes"]:
            if m not in MAKES: errors.append(f"{i}: unknown make {m}")
        if x["engine"] not in ENGINES: errors.append(f"{i}: bad engine")
        if x["severity"] not in SEV: errors.append(f"{i}: bad severity")
        if x["year_from"] > x["year_to"]: errors.append(f"{i}: year range")
        if x["cost_min_ils"] > x["cost_max_ils"]: errors.append(f"{i}: cost range")
        for lang in ("ar","en"):
            t = x["text"].get(lang)
            if not t: errors.append(f"{i}: missing {lang}"); continue
            for k in ("title","location","description","steps"):
                if not t.get(k): errors.append(f"{i}/{lang}: empty {k}")
            if len(t["steps"]) < 3: errors.append(f"{i}/{lang}: fewer than 3 steps")
print("total faults:", total)
print("symptoms covered:", sorted(used_symptoms))
print("symptoms with no fault:", sorted(SYMPTOMS - used_symptoms))
print("ERRORS:" if errors else "no structural errors")
for e in errors: print(" -", e)
sys.exit(1 if errors else 0)
