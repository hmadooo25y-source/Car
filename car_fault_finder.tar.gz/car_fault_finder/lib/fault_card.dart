import 'package:flutter/material.dart';

import 'models.dart';
import 'screens/detail_screen.dart';
import 'strings.dart';
import 'widgets.dart';

/// Compact fault card used by search and favourites lists.
class FaultCard extends StatelessWidget {
  final Fault fault;
  const FaultCard({super.key, required this.fault});

  @override
  Widget build(BuildContext context) {
    final text = fault.textFor(appLang.value);
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        contentPadding: const EdgeInsets.all(16),
        title: Text(
          text.title,
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 8),
          child: Row(
            children: [
              SeverityChip(severity: fault.severity),
              const SizedBox(width: 8),
              Flexible(
                child: Text(
                  '${fault.costMinIls}-${fault.costMaxIls} ${tr('currency')}',
                ),
              ),
            ],
          ),
        ),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => DetailScreen(fault: fault)),
        ),
      ),
    );
  }
}
