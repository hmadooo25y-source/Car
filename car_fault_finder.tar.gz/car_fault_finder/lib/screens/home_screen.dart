import 'package:flutter/material.dart';

import '../repository.dart';
import '../strings.dart';
import 'favorites_screen.dart';
import 'maintenance_screen.dart';
import 'obd_screen.dart';
import 'results_screen.dart';
import 'search_screen.dart';

class _SymptomDef {
  final String id;
  final IconData icon;
  final Color color;
  const _SymptomDef(this.id, this.icon, this.color);
}

const List<_SymptomDef> kSymptoms = [
  _SymptomDef('blue_smoke', Icons.cloud, Color(0xFF1565C0)),
  _SymptomDef('white_smoke', Icons.cloud_outlined, Color(0xFF607D8B)),
  _SymptomDef('knocking', Icons.graphic_eq, Color(0xFF6A1B9A)),
  _SymptomDef('overheating', Icons.thermostat, Color(0xFFD84315)),
  _SymptomDef('squealing', Icons.volume_up, Color(0xFF00838F)),
  _SymptomDef('check_engine', Icons.warning_amber, Color(0xFFF9A825)),
  _SymptomDef('hard_start', Icons.key, Color(0xFF5D4037)),
  _SymptomDef('rough_idle', Icons.vibration, Color(0xFF455A64)),
  _SymptomDef('oil_leak', Icons.water_drop, Color(0xFF2E7D32)),
  _SymptomDef('brake_noise', Icons.album, Color(0xFFB71C1C)),
];

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String? _make;
  String _engine = 'any';
  final TextEditingController _yearCtrl = TextEditingController();
  final TextEditingController _searchCtrl = TextEditingController();

  @override
  void dispose() {
    _yearCtrl.dispose();
    _searchCtrl.dispose();
    super.dispose();
  }

  void _toggleLanguage() {
    appLang.value = appLang.value == 'ar' ? 'en' : 'ar';
  }

  void _push(Widget screen) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => screen));
  }

  void _openSearch() {
    final q = _searchCtrl.text.trim();
    if (q.isEmpty) return;
    _push(SearchScreen(initialQuery: q));
  }

  void _openSymptom(String symptomId) {
    final yearText = _yearCtrl.text.trim();
    int? year;
    if (yearText.isNotEmpty) {
      year = int.tryParse(yearText);
      if (year == null || year < 1950 || year > 2030) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(tr('yearError'))),
        );
        return;
      }
    }

    _push(
      ResultsScreen(
        symptom: symptomId,
        make: _make,
        year: year,
        engineType: _engine == 'any' ? null : _engine,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(
        title: Text(tr('appTitle')),
        actions: [
          TextButton(
            onPressed: _toggleLanguage,
            child: Text(tr('lang')),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: _searchCtrl,
            textInputAction: TextInputAction.search,
            onSubmitted: (_) => _openSearch(),
            decoration: InputDecoration(
              hintText: tr('searchHint'),
              prefixIcon: const Icon(Icons.search),
              suffixIcon: IconButton(
                icon: const Icon(Icons.arrow_forward),
                onPressed: _openSearch,
              ),
              border: const OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              ActionChip(
                avatar: const Icon(Icons.star, size: 18),
                label: Text(tr('favorites')),
                onPressed: () => _push(const FavoritesScreen()),
              ),
              ActionChip(
                avatar: const Icon(Icons.qr_code, size: 18),
                label: Text(tr('obdTitle')),
                onPressed: () => _push(const ObdScreen()),
              ),
              ActionChip(
                avatar: const Icon(Icons.build, size: 18),
                label: Text(tr('maintenance')),
                onPressed: () => _push(const MaintenanceScreen()),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Text(
            tr('whatsWrong'),
            style: theme.textTheme.headlineSmall?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            tr('searchTip'),
            style: theme.textTheme.bodyMedium?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
          const SizedBox(height: 12),
          GridView.count(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisCount: 2,
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 1.25,
            children: kSymptoms.map((s) {
              return InkWell(
                borderRadius: BorderRadius.circular(16),
                onTap: () => _openSymptom(s.id),
                child: Card(
                  elevation: 1,
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(s.icon, size: 36, color: s.color),
                        const SizedBox(height: 8),
                        Text(
                          tr('sym_${s.id}'),
                          textAlign: TextAlign.center,
                          style: const TextStyle(fontWeight: FontWeight.w600),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 24),
          Text(
            tr('yourCar'),
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<String?>(
            value: _make,
            decoration: InputDecoration(
              labelText: tr('make'),
              border: const OutlineInputBorder(),
            ),
            items: [
              DropdownMenuItem<String?>(
                value: null,
                child: Text(tr('anyMake')),
              ),
              ...kMakes.map(
                (m) => DropdownMenuItem<String?>(value: m, child: Text(m)),
              ),
            ],
            onChanged: (v) => setState(() => _make = v),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _yearCtrl,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(
              labelText: tr('year'),
              hintText: tr('yearHint'),
              border: const OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          SegmentedButton<String>(
            segments: [
              ButtonSegment(value: 'any', label: Text(tr('engineAny'))),
              ButtonSegment(value: 'petrol', label: Text(tr('petrol'))),
              ButtonSegment(value: 'diesel', label: Text(tr('diesel'))),
            ],
            selected: {_engine},
            onSelectionChanged: (s) => setState(() => _engine = s.first),
          ),
          const SizedBox(height: 8),
          Text(
            tr('sourceNote'),
            style: theme.textTheme.bodySmall?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }
}
