import 'package:flutter/material.dart';

import '../repository.dart';
import '../strings.dart';
import 'results_screen.dart';

class _SymptomDef {
  final String id;
  final IconData icon;
  final Color color;
  const _SymptomDef(this.id, this.icon, this.color);
}

const List<_SymptomDef> kSymptoms = [
  _SymptomDef('blue_smoke', Icons.cloud, Color(0xFF1565C0)),
  _SymptomDef('white_smoke', Icons.cloud_outlined, Color(0xFF607D8B)),
  _SymptomDef('knocking', Icons.graphic_eq, Color(0xFF6A1B9A)),
  _SymptomDef('overheating', Icons.thermostat, Color(0xFFD84315)),
  _SymptomDef('squealing', Icons.volume_up, Color(0xFF00838F)),
  _SymptomDef('check_engine', Icons.warning_amber, Color(0xFFF9A825)),
  _SymptomDef('hard_start', Icons.key, Color(0xFF5D4037)),
  _SymptomDef('rough_idle', Icons.vibration, Color(0xFF455A64)),
  _SymptomDef('oil_leak', Icons.water_drop, Color(0xFF2E7D32)),
  _SymptomDef('brake_noise', Icons.album, Color(0xFFB71C1C)),
];

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String? _make;
  String _engine = 'any';
  final TextEditingController _yearCtrl = TextEditingController();

  @override
  void dispose() {
    _yearCtrl.dispose();
    super.dispose();
  }

  void _toggleLanguage() {
    appLang.value = appLang.value == 'ar' ? 'en' : 'ar';
  }

  void _openSymptom(String symptomId) {
    final yearText = _yearCtrl.text.trim();
    int? year;
    if (yearText.isNotEmpty) {
      year = int.tryParse(yearText);
      if (year == null || year < 1950 || year > 2030) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(tr('yearError'))),
        );
        return;
      }
    }

    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => ResultsScreen(
          symptom: symptomId,
          make: _make,
          year: year,
          engineType: _engine == 'any' ? null : _engine,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(tr('appTitle')),
        actions: [
          TextButton(
            onPressed: _toggleLanguage,
            child: Text(tr('lang')),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(
            tr('whatsWrong'),
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
          ),
          const SizedBox(height: 8),
          Text(
            tr('searchTip'),
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
          ),
          const SizedBox(height: 12),
          GridView.count(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisCount: 2,
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 1.25,
            children: kSymptoms.map((s) {
              return InkWell(
                borderRadius: BorderRadius.circular(16),
                onTap: () => _openSymptom(s.id),
                child: Card(
                  elevation: 1,
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(s.icon, size: 36, color: s.color),
                        const SizedBox(height: 8),
                        Text(
                          tr('sym_${s.id}'),
                          textAlign: TextAlign.center,
                          style: const TextStyle(fontWeight: FontWeight.w600),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 24),
          Text(
            tr('yourCar'),
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<String?>(
            value: _make,
            decoration: InputDecoration(
              labelText: tr('make'),
              border: const OutlineInputBorder(),
            ),
            items: [
              DropdownMenuItem<String?>(
                value: null,
                child: Text(tr('anyMake')),
              ),
              ...kMakes.map(
                (m) => DropdownMenuItem<String?>(value: m, child: Text(m)),
              ),
            ],
            onChanged: (v) => setState(() => _make = v),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _yearCtrl,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(
              labelText: tr('year'),
              hintText: tr('yearHint'),
              border: const OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            tr('sourceNote'),
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
          ),
          const SizedBox(height: 12),
          SegmentedButton<String>(
            segments: [
              ButtonSegment(value: 'any', label: Text(tr('engineAny'))),
              ButtonSegment(value: 'petrol', label: Text(tr('petrol'))),
              ButtonSegment(value: 'diesel', label: Text(tr('diesel'))),
            ],
            selected: {_engine},
            onSelectionChanged: (s) => setState(() => _engine = s.first),
          ),
        ],
      ),
    );
  }
}
