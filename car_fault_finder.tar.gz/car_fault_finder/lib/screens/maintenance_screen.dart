import 'package:flutter/material.dart';

import '../storage.dart';
import '../strings.dart';
import '../widgets.dart';

class MaintenanceItem {
  final String id;
  final String labelKey;
  final int intervalKm;
  const MaintenanceItem(this.id, this.labelKey, this.intervalKm);
}

/// Typical intervals in km. These are approximate; the car manual wins.
const List<MaintenanceItem> kMaintenance = [
  MaintenanceItem('oil', 'mnt_oil', 10000),
  MaintenanceItem('air', 'mnt_air', 20000),
  MaintenanceItem('cabin', 'mnt_cabin', 15000),
  MaintenanceItem('brake_fluid', 'mnt_brake_fluid', 40000),
  MaintenanceItem('spark', 'mnt_spark', 60000),
  MaintenanceItem('coolant', 'mnt_coolant', 60000),
  MaintenanceItem('timing', 'mnt_timing', 100000),
];

class MaintenanceScreen extends StatefulWidget {
  const MaintenanceScreen({super.key});

  @override
  State<MaintenanceScreen> createState() => _MaintenanceScreenState();
}

class _MaintenanceScreenState extends State<MaintenanceScreen> {
  final TextEditingController _kmCtrl = TextEditingController();
  int? _km;
  final Map<String, int?> _last = {};
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _kmCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final km = await AppStorage.carKm();
    final last = <String, int?>{};
    for (final item in kMaintenance) {
      last[item.id] = await AppStorage.serviceKm(item.id);
    }
    if (!mounted) return;
    setState(() {
      _km = km;
      _kmCtrl.text = km?.toString() ?? '';
      _last
        ..clear()
        ..addAll(last);
      _loaded = true;
    });
  }

  Future<void> _saveKm(String value) async {
    final km = int.tryParse(value.trim());
    if (km == null || km < 0) return;
    await AppStorage.setCarKm(km);
    if (!mounted) return;
    setState(() => _km = km);
  }

  Future<void> _editLast(MaintenanceItem item) async {
    final ctrl = TextEditingController(
      text: _last[item.id]?.toString() ?? '',
    );
    final value = await showDialog<int>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(tr(item.labelKey)),
        content: TextField(
          controller: ctrl,
          keyboardType: TextInputType.number,
          decoration: InputDecoration(
            labelText: '${tr('lastServiceKm')} (${tr('km')})',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text(tr('cancel')),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, int.tryParse(ctrl.text.trim())),
            child: Text(tr('save')),
          ),
        ],
      ),
    );
    if (value == null || value < 0) return;
    await AppStorage.setServiceKm(item.id, value);
    if (!mounted) return;
    setState(() => _last[item.id] = value);
  }

  Widget _status(MaintenanceItem item) {
    final last = _last[item.id];
    final km = _km;
    if (km == null) return Text(tr('enterKm'));
    if (last == null) return Text(tr('enterLast'));

    final left = last + item.intervalKm - km;
    final Color color;
    final String label;
    if (left <= 0) {
      color = Colors.red;
      label = tr('due');
    } else if (left <= 1000) {
      color = Colors.orange;
      label = tr('dueSoon');
    } else {
      color = Colors.green;
      label = tr('ok');
    }
    final text = left <= 0
        ? label
        : '$label • ${tr('kmLeft').replaceAll('{n}', '$left')}';
    return Text(
      text,
      style: TextStyle(color: color, fontWeight: FontWeight.bold),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(tr('maintenance'))),
      body: !_loaded
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                TextField(
                  controller: _kmCtrl,
                  keyboardType: TextInputType.number,
                  textInputAction: TextInputAction.done,
                  onSubmitted: _saveKm,
                  decoration: InputDecoration(
                    labelText: tr('carKm'),
                    suffixText: tr('km'),
                    border: const OutlineInputBorder(),
                    suffixIcon: IconButton(
                      icon: const Icon(Icons.save),
                      onPressed: () => _saveKm(_kmCtrl.text),
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  tr('maintenanceNote'),
                  style: Theme.of(context).textTheme.bodySmall,
                ),
                const SizedBox(height: 12),
                ...kMaintenance.map((item) {
                  final last = _last[item.id];
                  return Card(
                    margin: const EdgeInsets.only(bottom: 10),
                    child: ListTile(
                      contentPadding: const EdgeInsets.all(14),
                      title: Text(
                        tr(item.labelKey),
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(height: 4),
                          Text(
                            '${tr('every')} ${item.intervalKm} ${tr('km')}',
                          ),
                          if (last != null)
                            Text('${tr('lastServiceKm')}: $last ${tr('km')}'),
                          const SizedBox(height: 6),
                          _status(item),
                        ],
                      ),
                      trailing: const Icon(Icons.edit_outlined),
                      onTap: () => _editLast(item),
                    ),
                  );
                }),
              ],
            ),
    );
  }
}
