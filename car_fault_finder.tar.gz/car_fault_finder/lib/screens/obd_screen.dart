import 'package:flutter/material.dart';

import '../models.dart';
import '../repository.dart';
import '../strings.dart';
import '../widgets.dart';
import 'detail_screen.dart';

class ObdScreen extends StatefulWidget {
  const ObdScreen({super.key});

  @override
  State<ObdScreen> createState() => _ObdScreenState();
}

class _ObdScreenState extends State<ObdScreen> {
  final TextEditingController _ctrl = TextEditingController();
  String? _error;
  String? _code;
  ObdCode? _result;
  List<Fault> _related = [];
  bool _searched = false;

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  Future<void> _lookup() async {
    final code = _ctrl.text.trim().toUpperCase();
    if (!RegExp(r'^[PBCU][0-9A-F]{4}$').hasMatch(code)) {
      setState(() {
        _error = tr('obdInvalid');
        _searched = false;
        _result = null;
        _code = null;
      });
      return;
    }

    final codes = await FaultRepository.loadObdCodes();
    final all = await FaultRepository.load();
    final matches = codes.where((c) => c.code == code).toList();
    final ObdCode? result = matches.isEmpty ? null : matches.first;
    final related = result == null
        ? <Fault>[]
        : all.where((f) => result.relatedFaults.contains(f.id)).toList();

    if (!mounted) return;
    setState(() {
      _error = null;
      _code = code;
      _result = result;
      _related = related;
      _searched = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final result = _result;

    return Scaffold(
      appBar: AppBar(title: Text(tr('obdTitle'))),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: _ctrl,
            textCapitalization: TextCapitalization.characters,
            textInputAction: TextInputAction.search,
            onSubmitted: (_) => _lookup(),
            decoration: InputDecoration(
              hintText: tr('obdHint'),
              errorText: _error,
              border: const OutlineInputBorder(),
              suffixIcon: IconButton(
                icon: const Icon(Icons.search),
                onPressed: _lookup,
              ),
            ),
          ),
          if (_searched && _code != null) ...[
            const SizedBox(height: 20),
            if (result != null) ...[
              Text(
                _code!,
                style: theme.textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                result.textFor(appLang.value).title,
                style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
              ),
              const SizedBox(height: 8),
              SeverityChip(severity: result.severity),
              SectionTitle(tr('description')),
              Text(
                result.textFor(appLang.value).description,
                style: const TextStyle(fontSize: 15, height: 1.5),
              ),
              if (_related.isNotEmpty) ...[
                SectionTitle(tr('relatedFaults')),
                ..._related.map(
                  (f) => Card(
                    child: ListTile(
                      title: Text(f.textFor(appLang.value).title),
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () => Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (_) => DetailScreen(fault: f),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ] else ...[
              Text(tr('obdNotFound'), style: const TextStyle(fontSize: 15)),
              const SizedBox(height: 12),
              Text(
                tr('obdPrefix_${_code![0]}'),
                style: const TextStyle(fontSize: 15, height: 1.5),
              ),
            ],
          ],
        ],
      ),
    );
  }
}
