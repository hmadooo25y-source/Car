import 'package:flutter/material.dart';

import '../models.dart';
import '../storage.dart';
import '../strings.dart';
import '../widgets.dart';

class DetailScreen extends StatefulWidget {
  final Fault fault;
  const DetailScreen({super.key, required this.fault});

  @override
  State<DetailScreen> createState() => _DetailScreenState();
}

class _DetailScreenState extends State<DetailScreen> {
  bool _isFav = false;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final favs = await AppStorage.favorites();
    await AppStorage.addRecent(widget.fault.id);
    if (!mounted) return;
    setState(() => _isFav = favs.contains(widget.fault.id));
  }

  Future<void> _toggleFavorite() async {
    await AppStorage.toggleFavorite(widget.fault.id);
    final favs = await AppStorage.favorites();
    if (!mounted) return;
    setState(() => _isFav = favs.contains(widget.fault.id));
  }

  @override
  Widget build(BuildContext context) {
    final fault = widget.fault;
    final text = fault.textFor(appLang.value);
    final showWarning = fault.severity == 'critical' || fault.severity == 'high';

    return Scaffold(
      appBar: AppBar(
        title: Text(text.title),
        actions: [
          IconButton(
            tooltip: _isFav ? tr('removeFavorite') : tr('addFavorite'),
            icon: Icon(_isFav ? Icons.star : Icons.star_border),
            onPressed: _toggleFavorite,
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (showWarning)
            Container(
              padding: const EdgeInsets.all(14),
              margin: const EdgeInsets.only(bottom: 16),
              decoration: BoxDecoration(
                color: severityColor(fault.severity).withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: severityColor(fault.severity)),
              ),
              child: Text(
                text.warning ?? tr('stopWarning'),
                style: TextStyle(
                  color: severityColor(fault.severity),
                  fontWeight: FontWeight.bold,
                  fontSize: 15,
                ),
              ),
            ),
          if (fault.image != null)
            Padding(
              padding: const EdgeInsets.only(bottom: 16),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.asset(
                  fault.image!,
                  height: 200,
                  fit: BoxFit.contain,
                  errorBuilder: (context, error, stack) =>
                      const SizedBox.shrink(),
                ),
              ),
            ),
          Row(
            children: [
              Text(
                '${tr('severity')}: ',
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              SeverityChip(severity: fault.severity),
            ],
          ),
          const SizedBox(height: 4),
          SectionTitle(tr('location')),
          Text(text.location, style: const TextStyle(fontSize: 15)),
          SectionTitle(tr('description')),
          Text(text.description, style: const TextStyle(fontSize: 15, height: 1.5)),
          SectionTitle(tr('steps')),
          ...List.generate(text.steps.length, (i) {
            return Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CircleAvatar(
                    radius: 14,
                    child: Text('${i + 1}', style: const TextStyle(fontSize: 13)),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(text.steps[i], style: const TextStyle(fontSize: 15, height: 1.4)),
                  ),
                ],
              ),
            );
          }),
          SectionTitle(tr('cost')),
          Text(
            '${fault.costMinIls} - ${fault.costMaxIls} ${tr('currency')}',
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 24),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.grey.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Text(
              tr('disclaimer'),
              style: const TextStyle(fontSize: 13),
            ),
          ),
        ],
      ),
    );
  }
}
