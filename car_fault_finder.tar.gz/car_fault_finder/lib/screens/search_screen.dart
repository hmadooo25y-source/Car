import 'package:flutter/material.dart';

import '../fault_card.dart';
import '../models.dart';
import '../repository.dart';
import '../strings.dart';

class SearchScreen extends StatefulWidget {
  final String initialQuery;
  const SearchScreen({super.key, this.initialQuery = ''});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  late final TextEditingController _ctrl;
  late String _query;

  @override
  void initState() {
    super.initState();
    _query = widget.initialQuery.trim();
    _ctrl = TextEditingController(text: _query);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  /// Matches the query against the symptom labels, titles, locations,
  /// descriptions and ids of a fault, in the current language.
  bool _matches(Fault f, String query) {
    final t = f.textFor(appLang.value);
    final haystack = [
      t.title,
      t.location,
      t.description,
      f.id,
      ...f.symptoms.map((s) => tr('sym_$s')),
    ].join(' ').toLowerCase();
    return haystack.contains(query.toLowerCase());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(tr('search'))),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: TextField(
              controller: _ctrl,
              autofocus: _query.isEmpty,
              textInputAction: TextInputAction.search,
              onSubmitted: (v) => setState(() => _query = v.trim()),
              decoration: InputDecoration(
                hintText: tr('searchHint'),
                prefixIcon: const Icon(Icons.search),
                border: const OutlineInputBorder(),
              ),
            ),
          ),
          Expanded(
            child: _query.isEmpty
                ? const SizedBox.shrink()
                : FutureBuilder<List<Fault>>(
                    future: FaultRepository.load(),
                    builder: (context, snapshot) {
                      if (snapshot.connectionState != ConnectionState.done) {
                        return const Center(child: CircularProgressIndicator());
                      }
                      if (snapshot.hasError) {
                        return Center(child: Text('${snapshot.error}'));
                      }
                      final results = (snapshot.data ?? [])
                          .where((f) => _matches(f, _query))
                          .toList()
                        ..sort((a, b) => a.severityRank.compareTo(b.severityRank));
                      if (results.isEmpty) {
                        return Center(
                          child: Padding(
                            padding: const EdgeInsets.all(24),
                            child: Text(
                              tr('noSearchResults'),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        );
                      }
                      return ListView.builder(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        itemCount: results.length,
                        itemBuilder: (context, i) =>
                            FaultCard(fault: results[i]),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
