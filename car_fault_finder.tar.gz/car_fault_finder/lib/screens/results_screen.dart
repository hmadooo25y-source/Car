import 'package:flutter/material.dart';

import '../models.dart';
import '../repository.dart';
import '../strings.dart';
import '../widgets.dart';
import 'detail_screen.dart';

class ResultsScreen extends StatelessWidget {
  final String symptom;
  final String? make;
  final int? year;
  final String? engineType;

  const ResultsScreen({
    super.key,
    required this.symptom,
    this.make,
    this.year,
    this.engineType,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(tr('sym_$symptom'))),
      body: FutureBuilder<List<Fault>>(
        future: FaultRepository.load(),
        builder: (context, snapshot) {
          if (snapshot.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text('${snapshot.error}'));
          }

          final results = (snapshot.data ?? [])
              .where((f) => f.matches(
                    symptom: symptom,
                    make: make,
                    engineType: engineType,
                    year: year,
                  ))
              .toList()
            ..sort((a, b) => a.severityRank.compareTo(b.severityRank));

          if (results.isEmpty) {
            return Padding(
              padding: const EdgeInsets.all(24),
              child: Center(
                child: Text(
                  tr('noResults'),
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 16),
                ),
              ),
            );
          }

          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: results.length,
            itemBuilder: (context, index) {
              final fault = results[index];
              final text = fault.textFor(appLang.value);
              return Card(
                margin: const EdgeInsets.only(bottom: 12),
                child: ListTile(
                  contentPadding: const EdgeInsets.all(16),
                  title: Text(
                    text.title,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  subtitle: Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            SeverityChip(severity: fault.severity),
                            const SizedBox(width: 8),
                            Text(
                              '${fault.costMinIls}-${fault.costMaxIls} ${tr('currency')}',
                            ),
                          ],
                        ),
                        if (fault.makes.isNotEmpty) ...[
                          const SizedBox(height: 6),
                          Text(
                            '${tr('onlyFor')}: ${fault.makes.join(', ')}',
                            style: TextStyle(
                              fontSize: 12,
                              color: Theme.of(context)
                                  .colorScheme
                                  .onSurfaceVariant,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (_) => DetailScreen(fault: fault),
                    ),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
