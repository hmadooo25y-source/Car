import 'package:flutter/material.dart';

import '../fault_card.dart';
import '../models.dart';
import '../repository.dart';
import '../storage.dart';
import '../strings.dart';
import '../widgets.dart';

class _FavData {
  final List<Fault> favorites;
  final List<Fault> recent;
  const _FavData(this.favorites, this.recent);
}

class FavoritesScreen extends StatefulWidget {
  const FavoritesScreen({super.key});

  @override
  State<FavoritesScreen> createState() => _FavoritesScreenState();
}

class _FavoritesScreenState extends State<FavoritesScreen> {
  late Future<_FavData> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<_FavData> _load() async {
    final all = await FaultRepository.load();
    final favIds = await AppStorage.favorites();
    final recentIds = await AppStorage.recent();
    final byId = {for (final f in all) f.id: f};
    final favorites = all.where((f) => favIds.contains(f.id)).toList();
    final recent = recentIds.map((id) => byId[id]).whereType<Fault>().toList();
    return _FavData(favorites, recent);
  }

  Future<void> _refresh() async {
    setState(() => _future = _load());
    await _future;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(tr('favorites'))),
      body: FutureBuilder<_FavData>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          final data = snapshot.data ?? const _FavData([], []);
          return RefreshIndicator(
            onRefresh: _refresh,
            child: ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              padding: const EdgeInsets.all(16),
              children: [
                if (data.favorites.isEmpty)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 24),
                    child: Text(tr('noFavorites'), textAlign: TextAlign.center),
                  )
                else
                  ...data.favorites.map((f) => FaultCard(fault: f)),
                if (data.recent.isNotEmpty) ...[
                  SectionTitle(tr('recent')),
                  ...data.recent.map((f) => FaultCard(fault: f)),
                ],
              ],
            ),
          );
        },
      ),
    );
  }
}
