import 'package:flutter/material.dart';

import 'strings.dart';

Color severityColor(String severity) {
  switch (severity) {
    case 'critical':
      return const Color(0xFFB71C1C);
    case 'high':
      return const Color(0xFFE64A19);
    case 'medium':
      return const Color(0xFFF9A825);
    default:
      return const Color(0xFF2E7D32);
  }
}

class SeverityChip extends StatelessWidget {
  final String severity;
  const SeverityChip({super.key, required this.severity});

  @override
  Widget build(BuildContext context) {
    final color = severityColor(severity);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.15),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color),
      ),
      child: Text(
        tr('sev_$severity'),
        style: TextStyle(color: color, fontWeight: FontWeight.bold),
      ),
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String text;
  const SectionTitle(this.text, {super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 20, bottom: 8),
      child: Text(
        text,
        style: Theme.of(context).textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.bold,
            ),
      ),
    );
  }
}
