/// One fault entry as stored in assets/data/faults.json.
class Fault {
  final String id;
  final List<String> symptoms;
  final List<String> makes; // empty list = applies to all makes
  final String engine; // 'any', 'petrol' or 'diesel'
  final int yearFrom;
  final int yearTo;
  final String severity; // 'low', 'medium', 'high', 'critical'
  final int costMinIls;
  final int costMaxIls;
  final Map<String, FaultText> texts; // keyed by language code

  const Fault({
    required this.id,
    required this.symptoms,
    required this.makes,
    required this.engine,
    required this.yearFrom,
    required this.yearTo,
    required this.severity,
    required this.costMinIls,
    required this.costMaxIls,
    required this.texts,
  });

  factory Fault.fromJson(Map<String, dynamic> json) {
    final rawTexts = json['text'] as Map<String, dynamic>;
    return Fault(
      id: json['id'] as String,
      symptoms: (json['symptoms'] as List).cast<String>(),
      makes: (json['makes'] as List).cast<String>(),
      engine: json['engine'] as String,
      yearFrom: json['year_from'] as int,
      yearTo: json['year_to'] as int,
      severity: json['severity'] as String,
      costMinIls: json['cost_min_ils'] as int,
      costMaxIls: json['cost_max_ils'] as int,
      texts: rawTexts.map(
        (lang, value) =>
            MapEntry(lang, FaultText.fromJson(value as Map<String, dynamic>)),
      ),
    );
  }

  /// Text for the requested language, falling back to English.
  FaultText textFor(String lang) => texts[lang] ?? texts['en']!;

  /// Severity rank used for sorting: critical first.
  int get severityRank {
    switch (severity) {
      case 'critical':
        return 0;
      case 'high':
        return 1;
      case 'medium':
        return 2;
      default:
        return 3;
    }
  }

  bool matches({
    required String symptom,
    String? make,
    String? engineType,
    int? year,
  }) {
    if (!symptoms.contains(symptom)) return false;
    if (makes.isNotEmpty && make != null && !makes.contains(make)) return false;
    if (engine != 'any' && engineType != null && engine != engineType) {
      return false;
    }
    if (year != null && (year < yearFrom || year > yearTo)) return false;
    return true;
  }
}

class FaultText {
  final String title;
  final String location;
  final String description;
  final List<String> steps;
  final String? warning;

  const FaultText({
    required this.title,
    required this.location,
    required this.description,
    required this.steps,
    this.warning,
  });

  factory FaultText.fromJson(Map<String, dynamic> json) {
    return FaultText(
      title: json['title'] as String,
      location: json['location'] as String,
      description: json['description'] as String,
      steps: (json['steps'] as List).cast<String>(),
      warning: json['warning'] as String?,
    );
  }
}
