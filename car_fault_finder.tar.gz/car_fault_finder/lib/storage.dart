import 'package:shared_preferences/shared_preferences.dart';

/// Small on-device storage: favourites, recently viewed faults, odometer and
/// maintenance records. Every call fails silently so the app keeps working.
class AppStorage {
  static const _kFavorites = 'favorites';
  static const _kRecent = 'recent';
  static const _kCarKm = 'car_km';
  static const _kServicePrefix = 'service_km_';
  static const _maxRecent = 10;

  static Future<SharedPreferences?> _prefs() async {
    try {
      return await SharedPreferences.getInstance();
    } catch (_) {
      return null;
    }
  }

  static Future<Set<String>> favorites() async {
    try {
      final p = await _prefs();
      return (p?.getStringList(_kFavorites) ?? <String>[]).toSet();
    } catch (_) {
      return <String>{};
    }
  }

  static Future<void> toggleFavorite(String id) async {
    try {
      final p = await _prefs();
      if (p == null) return;
      final set = (p.getStringList(_kFavorites) ?? <String>[]).toSet();
      if (set.contains(id)) {
        set.remove(id);
      } else {
        set.add(id);
      }
      await p.setStringList(_kFavorites, set.toList());
    } catch (_) {}
  }

  static Future<List<String>> recent() async {
    try {
      final p = await _prefs();
      return p?.getStringList(_kRecent) ?? <String>[];
    } catch (_) {
      return <String>[];
    }
  }

  static Future<void> addRecent(String id) async {
    try {
      final p = await _prefs();
      if (p == null) return;
      final list = List<String>.from(p.getStringList(_kRecent) ?? <String>[]);
      list.remove(id);
      list.insert(0, id);
      if (list.length > _maxRecent) {
        list.removeRange(_maxRecent, list.length);
      }
      await p.setStringList(_kRecent, list);
    } catch (_) {}
  }

  static Future<int?> carKm() async {
    try {
      final p = await _prefs();
      return p?.getInt(_kCarKm);
    } catch (_) {
      return null;
    }
  }

  static Future<void> setCarKm(int km) async {
    try {
      final p = await _prefs();
      await p?.setInt(_kCarKm, km);
    } catch (_) {}
  }

  static Future<int?> serviceKm(String itemId) async {
    try {
      final p = await _prefs();
      return p?.getInt('$_kServicePrefix$itemId');
    } catch (_) {
      return null;
    }
  }

  static Future<void> setServiceKm(String itemId, int km) async {
    try {
      final p = await _prefs();
      await p?.setInt('$_kServicePrefix$itemId', km);
    } catch (_) {}
  }
}
