import 'dart:convert';

import 'package:flutter/services.dart' show rootBundle;

import 'models.dart';

/// Data files loaded and merged at startup. Add new files here.
const List<String> kDataFiles = [
  'assets/data/faults.json',
  'assets/data/faults_more.json',
];

/// Makes shown in the dropdown. Keep names identical to the "makes" values in the JSON files.
const List<String> kMakes = [
  'Toyota',
  'Hyundai',
  'Kia',
  'Nissan',
  'Chevrolet',
  'Mercedes-Benz',
  'BMW',
  'Peugeot',
  'Renault',
  'Volkswagen',
  'Skoda',
  'Mazda',
  'Honda',
  'Ford',
];

class FaultRepository {
  static List<Fault>? _cache;

  static Future<List<Fault>> load() async {
    if (_cache != null) return _cache!;
    final faults = <Fault>[];
    for (final path in kDataFiles) {
      final raw = await rootBundle.loadString(path);
      final data = json.decode(raw) as Map<String, dynamic>;
      faults.addAll(
        (data['faults'] as List)
            .map((e) => Fault.fromJson(e as Map<String, dynamic>)),
      );
    }
    _cache = faults;
    return _cache!;
  }
}
