import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'screens/home_screen.dart';
import 'strings.dart';

void main() {
  runApp(const CarFaultApp());
}

class CarFaultApp extends StatelessWidget {
  const CarFaultApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<String>(
      valueListenable: appLang,
      builder: (context, lang, _) {
        return MaterialApp(
          title: 'Car Fault Finder',
          debugShowCheckedModeBanner: false,
          locale: Locale(lang),
          supportedLocales: const [Locale('ar'), Locale('en')],
          localizationsDelegates: const [
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          theme: ThemeData(
            colorSchemeSeed: const Color(0xFF1565C0),
            useMaterial3: true,
          ),
          // Not const on purpose: a new instance lets the screen rebuild on language change.
          home: HomeScreen(),
        );
      },
    );
  }
}
